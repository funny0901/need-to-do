**Insufficient Clear Procedure**  

- use the insufficient clear observations

- using the green band, update Persistent Processing Maks to exclude
  observations exceeding:
  green_band_media + 400

- [do a generalized curve fit for observation set] (lasso_fit.md)
